import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.awt.Rectangle; 
import java.awt.Robot; 
import java.awt.AWTException; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class prtscrn_test extends PApplet {






PImage img;
String answer="Your Target..";
PImage[] caches;
String[] names;
PVector start_pos;
PVector size;

public void setup() {
  
  String[] config=loadStrings("config");
  start_pos=new PVector(PApplet.parseFloat(config[0]), PApplet.parseFloat(config[1]));
  size=new PVector(start_pos.x+PApplet.parseFloat(config[2]), start_pos.y+PApplet.parseFloat(config[3]));
  File[] files=new File(sketchPath()+"\\data").listFiles();
  caches=new PImage[files.length];
  names=new String[files.length];
  for (int i=0, j=files.length; i<j; i++) {
    caches[i]=loadImage(files[i].toString());
    String tmp=files[i].getName();
    names[i]=tmp.substring(0, tmp.length()-4);
  }
  background(0);
  text("wtf path\n"+sketchPath()+"\\data", 0, 0, width, height);
  textLeading(16);
}

boolean action_toggle=false;
int idle_start=0;
int IDLE_LIMIT=50;
public void draw() {
  if (action_toggle && img != null) {
    background(0);
    text(answer, 0, 0, width, height);
    answer="Process on "+millis()+":\n";
    for (int i=0, j=caches.length; i<j; i++) {
      boolean isSamePixel=true;
      for (float y=start_pos.y; y<size.y; y++) {
        for (float x=start_pos.x; x<size.x; x++) {
          int index=PApplet.parseInt(x)+PApplet.parseInt(y)*img.width;
          int c_index=PApplet.parseInt(x)+PApplet.parseInt(y)*caches[i].width;
          int img_c=img.pixels[index];
          int cache_c=caches[i].pixels[c_index];
          isSamePixel=img_c==cache_c;
          if (!isSamePixel) break;
        }
        if (!isSamePixel) break;
      }
      if (isSamePixel) {
        answer+=names[i]+'\n';
      }
    }
    action_toggle=false;
  }
  if (!action_toggle && idle_start==0) {
    idle_start=millis();
  } else if (!action_toggle) {
    if (millis()-IDLE_LIMIT>idle_start) {
      idle_start=0;
      action_toggle=true;
      try {
        img = new PImage(new Robot().createScreenCapture(new Rectangle(0, 0, displayWidth, displayHeight)));
      } 
      catch (AWTException e) {
      }
    }
  }
}
  public void settings() {  size(200, 450); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "prtscrn_test" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
